package com.advance;

public class ArrSumAvg {
	public static void main(String[] args) {      
		int my_array[] = { 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0,0};
		int sum = 0;

		for (int i : my_array) {
		    sum += i;
		System.out.println("The sum is " + sum);
		}
		int s = 0;
	       for(int i=0; i < my_array.length ; i++) {
	        s = s + my_array[i];
	       //calculate average value
	        double average = s / my_array.length;
	        System.out.println("Average value of the array elements is : " + average);}
	       int min = my_array[0];  
	          
	        //Loop through the array  
	        for (int i = 0; i < my_array.length; i++) {   
	            //Compare elements of array with min  
	           if(my_array[i] < min)  
	               min = my_array[i];  
	        }    
	        System.out.println("Smallest element present in given array: " + min);  
	    }  
		}

