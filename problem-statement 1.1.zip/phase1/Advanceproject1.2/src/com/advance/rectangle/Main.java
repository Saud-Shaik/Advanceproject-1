package com.advance.rectangle;

public class Main {
	public static void main(String[] args) {
		Rectangle ob1=new Rectangle(2.0,5.2,6.3);
		ob1.surfacearea();
		ob1.volume();
		
		Rectangle ob2=new Rectangle(2.5,5.9,3.3);
		ob2.surfacearea();
		ob2.volume();
		
		Rectangle ob3=new Rectangle(8.5,2.9,3.1);
		ob3.surfacearea();
		ob3.volume();
		
		Rectangle ob4=new Rectangle(2.6,5.5,7.1);
		ob4.surfacearea();
		ob4.volume();
		
		Rectangle ob5=new Rectangle(2.3,4.2,6.0);
		ob5.surfacearea();
		ob5.volume();
		
		
	}

}
