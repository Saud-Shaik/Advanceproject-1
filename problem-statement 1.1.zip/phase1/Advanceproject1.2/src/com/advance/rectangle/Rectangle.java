package com.advance.rectangle;

class Rectangle {
    double length;
    double breadth;
    double height;

    public Rectangle(double l, double b, double h) {
        length = l;
        breadth = b;
        height = h;
    }

    public void surfacearea() {
        double sa = 2 * (length * breadth + breadth * height + length * height);
        System.out.println("Surface Area = " + sa);
    }

    public void volume() {
        double vol = length * breadth * height;
        System.out.println("Volume = " + vol);
    }
}