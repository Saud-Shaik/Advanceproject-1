package com.advance;

import java.util.ArrayList;

public class ListOfStudents {
	public static void main(String args[]){  
	      ArrayList<String> alist=new ArrayList<String>();  
	      alist.add("Steve");
	      alist.add("Tim");
	      alist.add("Lucy");
	      alist.add("Pat");
	      alist.add("Angela");
	      alist.add("Tom");
	  
	      //displaying elements
	      System.out.println(alist);
	  
	      //Adding "Steve" at the fourth position
	      alist.add(3, "Steve");
	  
	      //displaying elements
	      System.out.println(alist);
	      
	      if(alist.contains("Tim"))
	          System.out.println("student is present in the ArrayList");
	       else
	          System.out.println("student is not present in the ArrayList");
	   }  
	 
}
