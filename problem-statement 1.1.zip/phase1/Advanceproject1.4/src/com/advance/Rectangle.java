package com.advance;

public class Rectangle {
 public static void main(String[] args) {
	TestRectangle rect1=new TestRectangle();
	TestRectangle rect2=new TestRectangle(15.0,8.0);
	System.out.println("Area of first object="+rect1.getArea());
	System.out.println("Perimeter of first object="+rect1.getPerimeter());
	System.out.println("Area of second object="+rect2.getArea());
	System.out.println("Perimeter of second object="+rect2.getPerimeter());
	
	
	System.out.println();
	rect2.setValues(10, 5);
	rect2.doLength();
	rect2.doWidth();
	System.out.println("Length=" +rect2.getArea());
	System.out.println("Perimeter of rectangle:"+rect2.getPerimeter());
	
	
	
}
}
class TestRectangle{
	double length,width;
	 TestRectangle(){
		 length=1;
		 width=1;
	 }
	 TestRectangle(double length,double width){
		 this.length=length;
		 this.width=width;
	 }
	 double getArea()
	 {
		 return(length*width);
	 }
	 double getPerimeter()
	 {
		 return (2*(length + width));
	 }
	 public void setValues(double length,double width)
	 {
		 if(length > 0 && length < 20)
			 this.length=length;
		 if (width > 0 && width < 20)
			 this.width=width;
	 }
	 public double doLength()
	 {
		 return length;
	 }
	 public double doWidth()
	 {
		 return width;
	 }
}
