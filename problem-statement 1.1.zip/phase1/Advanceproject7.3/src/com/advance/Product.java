package com.advance;

public class Product {

}
