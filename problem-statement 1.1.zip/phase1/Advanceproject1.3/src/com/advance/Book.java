package com.advance;

public class Book {
	public static void main(String[] args) {
		Book1[] ob=new Book1[2];
		ob[0]=new Book1();
		ob[0].setBook_title("Java programming");
		ob[0].setPrice(350.50);
		ob[0].createBooks();
		ob[0].showBooks();
		
		ob[1]=new Book1();
		ob[1].setBook_title("Let us C");
		ob[1].setPrice(200.00);
		ob[1].createBooks();
		ob[1].showBooks();
		
	}

}
class Book1{
	private String book_title;
	private double price;
	public String getBook_title() {
		return book_title;
	}
	
	

	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void createBooks() {
		System.out.println("book_title="+book_title);
	}
	public void showBooks() {
		System.out.println("price="+price);
	}
}
