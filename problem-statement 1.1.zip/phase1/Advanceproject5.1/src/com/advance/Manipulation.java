package com.advance;

public class Manipulation {
public static void main(String[] args) {
	String str="JAVA IS SIMPLE";//convert to lowercase
	System.out.println("Convert to lowercase:"+ str.toLowerCase());
	System.out.println("Convert to Uppercase:"+str.toUpperCase());
	System.out.println("char at:"+str.charAt(0) +str.charAt(5) +str.charAt(8));
	String[] stringArr=str.split("");
	for(int i=0;i<stringArr.length;i++)
	{
		System.out.print(stringArr[i]);
	}
	System.out.println("Length of str is:"+str.length());
}
}
