package com.advance;

import java.util.Scanner;

public class Palindrome {
	
	public static int isPalindrome(String str1)
    {
		String str1, rev = "";
	      Scanner sc = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      str1 = sc.nextLine();
	 
	      int length = str1.length();
	 
	      for ( int i = length - 1; i >= 0; i-- )
	         rev = rev + str1.charAt(i);
	 
	      if (str1.equals(rev))
	         System.out.println(str1+" is a palindrome");
	      else
	         System.out.println(str1+" is not a palindrome");
    }

}
