package com.advance;

import java.util.LinkedList;

public class TestEmployee {
public static void main(String[] args) {
	LinkedList<Employee> ll = new LinkedList<Employee>();
			addInput();
	display(ll);
	
}
public static LinkedList<Employee> addInput(){
	Employee e1=new Employee(101,"Tony","Stark");
	Employee e2=new Employee(102,"tom","cruise");
	Employee e3=new Employee(103,"Tom","Hardy");
	LinkedList<Employee> ll=new LinkedList<Employee>();
	ll.add(e1);
	ll.add(e2);
	ll.add(e3);
	return ll;
}
public static void display(LinkedList<Employee>ll)
{
	for(Employee e:ll) {
	System.out.println(e.getEmpno()+"\t"+e.getEname()+"\t"+e.getAddress());
	}
	}
}
