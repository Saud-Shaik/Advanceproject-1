package com.advance;

public class Employee {
private int empno;
private String ename,address;
public Employee(int empno, String ename, String address) {
	super();
	this.empno = empno;
	this.ename = ename;
	this.address = address;
	
}
public int getEmpno() {
	return empno;
}
public void setEmpno(int empno) {
	this.empno = empno;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}


}



