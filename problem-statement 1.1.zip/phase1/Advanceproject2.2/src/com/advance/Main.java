package com.advance;

public class Main {
	public static void main(String[] args) {

	    int n = 15, firstTerm = 1, secondTerm = 3;
	    System.out.println("Series till " + n + " terms:");

	    for (int i = 1; i <= n; ++i) {
	      System.out.print(firstTerm + ", ");

	      // compute the next term
	      int nextTerm = firstTerm + secondTerm;
	      firstTerm = secondTerm;
	      secondTerm = nextTerm;
	    }
	  }
}
