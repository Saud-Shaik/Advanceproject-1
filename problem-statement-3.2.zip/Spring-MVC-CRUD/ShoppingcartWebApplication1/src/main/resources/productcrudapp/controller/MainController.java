package productcrudapp.controller;


import java.util.List;    
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ModelAttribute;    
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMethod;  

import productcrudapp.dao.ProductDao;
import productcrudapp.model.Product;

@Controller
public class MainController {
//	@RequestMapping("/")
//public String home()
//{
//	return "index";
//	}
//	@RequestMapping("/add-product")
//	public String addProduct(Model m)
//	{
//		m.addAttribute("title", "Add product");
//		return "add_product_form";
//	}
	
	@Autowired    
    ProductDao dao;//will inject dao from XML file    
        
    /*It displays a form to input data, here "command" is a reserved request attribute  
     *which is used to display object data into form  
     */    
    @RequestMapping("/productform")    
    public String showform(Model m){    
        m.addAttribute("command", new Product());  
        return "productform";   
    }    
    /*It saves object into database. The @ModelAttribute puts request data  
     *  into model object. You need to mention RequestMethod.POST method   
     *  because default request is GET*/    
    @RequestMapping(value="/save",method = RequestMethod.POST)    
    public String save(@ModelAttribute("product") Product product){    
        dao.save(product);    
        return "redirect:/viewproduct";//will redirect to viewemp request mapping    
    }    
    /* It provides list of employees in model object */    
    @RequestMapping("/viewproduct")    
    public String viewproduct(Model m){    
        List<Product> list=dao.getProduct();    
        m.addAttribute("list",list);  
        return "viewproduct";    
    }    
    /* It displays object data into form for the given id.   
     * The @PathVariable puts URL data into variable.*/    
    @RequestMapping(value="/editproduct/{id}")    
    public String edit(@PathVariable int id, Model m){    
        Product product=dao.getProductById(id);    
        m.addAttribute("command",product);  
        return "producteditform";    
    }    
    /* It updates model object. */    
    @RequestMapping(value="/editsave",method = RequestMethod.POST)    
    public String editsave(@ModelAttribute("product") Product product){    
        dao.update(product);    
        return "redirect:/viewproduct";    
    }    
    /* It deletes record for the given id in URL and redirects to /viewproduct */    
    @RequestMapping(value="/deleteproduct/{id}",method = RequestMethod.GET)    
    public String delete(@PathVariable int id){    
        dao.delete(id);    
        return "redirect:/viewproduct";    
    }     
}
